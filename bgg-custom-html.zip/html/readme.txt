This is a set of custom html files designed to be used with the Open Source BroadcastGG tool.

These files are designed to make the Team1 and Team2 scenes usable with other games, and also fixing some of the scoreboard sizing to look better for other games

They are by no means perfect, but they get the job done.

lol1/lol2 - 5 players
rl1/rl2 - 3 players with role cards removed (this also works for 3v3 smash)
val1/val2 - 5 players with role cards removed
smashfullroster - 6 players with role cards removed
scoreboardlol - scoreboard with adjusted sizing
scoeboardlolcolorlocked - scoreboard with adjusted sizing, locked to default LoL Blue and Red colors
scoreboardrl - scoreboard adjusted to Rocket League sizing
scoreboardval - scoreboard adjusted to Valorant Sizing
